<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Sistem Informasi Geospasial Halal (SIG-Halal) Sawangan. Solusi pemetaan terpadu untuk kebutuhan akademik SIG.">
    <title><?= $title ?></title>
    <link rel="icon" href="https://placehold.co/32x32/00BCD4/FFFFFF?text=SIG" type="image/png">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css" />
    
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css?v=14.0') ?>">
    <style>
        /* Perbaikan: Atur Scroll Margin Top untuk Fix Anchor Link */
        :target {
            scroll-margin-top: 80px; /* Nilai harus lebih besar dari tinggi navbar */
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 sticky-top shadow-sm border-bottom" id="mainNavbar">
        <div class="container">
            <a class="navbar-brand fw-bolder text-teal" href="<?= base_url() ?>">
                <i class="bi bi-map-fill me-2 text-coral"></i> <b>SIG-HALAL.id</b>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link fw-semibold text-dark" href="#"><i class="bi bi-house"></i> Beranda</a></li>
                    <li class="nav-item"><a class="nav-link fw-semibold text-dark" href="#halal-info"><i class="bi bi-journal-text"></i> Pengetahuan Halal</a></li>
                    <li class="nav-item"><a class="nav-link fw-semibold text-dark" href="#peta"><i class="bi bi-geo-alt"></i> Peta Interaktif</a></li>
                    <li class="nav-item"><a class="nav-link fw-semibold text-dark" href="#project-info"><i class="bi bi-code-slash"></i> Info Proyek</a></li>
                    <li class="nav-item"><a class="nav-link fw-semibold btn btn-sm btn-coral ms-lg-2 text-white" href="#contact"><i class="bi bi-person-lines-fill"></i> Kontak</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <header class="hero-section text-dark py-5" style="background-image: linear-gradient(to right, #E0F7FA, #B2EBF2);">
        <div class="container text-center py-5" style="margin-top: 55px;">
            <h1 class="display-3 fw-bolder mb-3 text-teal">SISTEM INFORMASI GEOSPASIAL HALAL</h1>
            <h2 class="h4 mb-4 text-secondary">Area Studi: Kecamatan Sawangan, Kota Depok</h2>
            <p class="lead mx-auto mb-5 text-muted" style="max-width: 900px;">
                Sebuah proyek akademik yang bertujuan untuk memvisualisasikan data sertifikasi Halal ke dalam peta interaktif, meningkatkan transparansi data geografis.
            </p>
            <a href="#peta" class="btn btn-teal btn-lg mt-3 fw-bold shadow-lg rounded-pill text-white"><i class="bi bi-pin-map me-2"></i> Jelajahi Peta Sekarang</a>
        </div>
    </header>
    
    <section id="halal-info" class="py-5 bg-white border-bottom">
        <div class="container">
            <h2 class="text-center fw-bolder mb-5 text-coral"><i class="bi bi-lightbulb-fill me-2"></i> Pengetahuan Seputar Makanan Halal yang Lengkap</h2>
            
            <div class="row align-items-center mb-5">
                <div class="col-lg-7 mb-4 mb-lg-0">
                    <h4 class="fw-bold text-teal mb-3">Definisi Halal dan Thayyib</h4>
                    <p class="text-muted">
                        Halal (<span class="fw-semibold text-dark">حلال</span>) berarti diizinkan atau diperbolehkan oleh syariat Islam. Konsep ini selalu bergandengan dengan <b>Thayyib</b> (<span class="fw-semibold text-dark">طيب</span>) yang berarti baik, bersih, aman, dan bergizi. Makanan yang dikonsumsi harus memenuhi kedua syarat ini.
                    </p>
                    
                    <div class="card bg-teal-soft border-0 p-3 mt-4">
                         <h5 class="fw-bold text-teal mb-2">Landasan Dalil Al-Qur'an</h5>
                         <blockquote class="blockquote border-start border-3 border-coral ps-3">
                            <p class="mb-1 fs-5 text-dark" style="font-family: 'Times New Roman', serif; direction: rtl; font-size: 1.5rem;">
                                يَا أَيُّهَا النَّاسُ كُلُوا مِمَّا فِي الْأَرْضِ حَلَالًا طَيِّبًا 
                            </p>
                            <p class="mb-0 fs-6 fst-italic text-dark">
                                "Wahai sekalian manusia, makanlah yang halal lagi baik (thayyib) dari apa yang terdapat di bumi..."
                            </p>
                        </blockquote>
                        <figcaption class="blockquote-footer">
                            Al-Qur'an Surat Al-Baqarah Ayat 168
                        </figcaption>
                    </div>
                </div>
                <div class="col-lg-5 text-center">
                    <img src="<?= base_url('assets/images/halal.png') ?>" class="img-fluid rounded-3 shadow-lg" alt="Ilustrasi Halal dan Thayyib">
                </div>
            </div>

            <h4 class="fw-bold text-teal mb-4 text-center border-bottom pb-2">Aspek dan Ciri-ciri Makanan Halal</h4>
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card border-0 shadow-sm h-100 p-3 card-teal-light">
                        <div class="card-body">
                            <i class="bi bi-layers-fill display-5 text-teal mb-2"></i>
                            <h5 class="fw-bold text-teal">1. Kategori Bahan Halal</h5>
                            <ul class="list-unstyled small mt-3">
                                <li>✅ Dari Hewan: Disembelih (ذبح) sesuai syariat (tidak termasuk babi, anjing, atau hewan buas).</li>
                                <li>✅ Dari Tumbuhan: Semua yang tidak memabukkan dan tidak beracun (kecuali ada dalil yang mengharamkan).</li>
                                <li>✅ Dari Air/Mineral: Semua yang tidak membahayakan.</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card border-0 shadow-sm h-100 p-3 card-coral-light">
                        <div class="card-body">
                            <i class="bi bi-gear-fill display-5 text-coral mb-2"></i>
                            <h5 class="fw-bold text-coral">2. Proses & Pengolahan</h5>
                            <ul class="list-unstyled small mt-3">
                                <li>❌ Bebas Kontaminasi: Alat masak/olah harus bebas dari najis (seperti darah atau air liur anjing/babi).</li>
                                <li>❌ Bebas Khamr: Produk tidak mengandung alkohol (khamr) atau bahan turunan haram lainnya.</li>
                                <li>✅ Sertifikasi: Memiliki jaminan sertifikasi dari lembaga berwenang (LPH/BPJPH/MUI).</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="peta" class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bolder text-teal"><i class="bi bi-map-fill me-2"></i> Peta Interaktif Sawangan (Data Studi Kasus)</h2>
                <p class="text-muted lead">Gunakan <b>Filter</b> dan <b>Layer Control</b> untuk eksplorasi data sertifikasi Halal di wilayah studi.</p>
            </div>

            <div class="card shadow-lg mb-4 border-start border-4 border-coral">
                <div class="card-body">
                    <h5 class="card-title text-coral fw-bold"><i class="bi bi-funnel-fill me-2"></i> Filter Data Lokasi</h5>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label for="filterJenis" class="form-label small fw-semibold">Jenis Usaha:</label>
                            <select id="filterJenis" class="form-select form-select-sm rounded-0">
                                <option value="all">-- Tampilkan Semua Jenis --</option>
                                <option value="Restoran">Restoran/Cafe</option>
                                <option value="Rumah Makan">Rumah Makan/Warung</option>
                                <option value="UMKM">UMKM/Pangan Olahan</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="filterSertifikat" class="form-label small fw-semibold">Lembaga Verifikasi:</label>
                            <select id="filterSertifikat" class="form-select form-select-sm rounded-0">
                                <option value="all">-- Tampilkan Semua Lembaga --</option>
                                <option value="BPJPH">BPJPH (Lembaga A)</option>
                                <option value="MUI">MUI (Lembaga B)</option>
                                <option value="BPOM">BPOM (Lembaga C)</option>
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button id="resetFilter" class="btn btn-outline-teal btn-sm w-100 rounded-0 fw-semibold"><i class="bi bi-arrow-clockwise me-1"></i> Atur Ulang Filter</button>
                        </div>
                    </div>
                </div>
            </div>
            <div id="map" class="map-container shadow-lg" style="height: 650px; width: 100%;"></div>
        </div>
    </section>

    <section id="project-info" class="py-5 bg-white border-top border-bottom">
        <div class="container">
            <h2 class="fw-bolder text-center mb-5 text-teal"><i class="bi bi-code-slash me-2"></i> Informasi Proyek & Implementasi Teknis</h2>
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0">
                    <h4 class="fw-bold text-teal mb-3">Website Ini Dibangun Dengan:</h4>
                    <ul class="list-group list-group-flush mt-3">
                        <li class="list-group-item px-0 fw-semibold"><i class="bi bi-check-circle-fill text-coral me-2"></i> <b>Framework Back-End:</b> CodeIgniter (PHP) untuk struktur MVC.</li>
                        <li class="list-group-item px-0 fw-semibold"><i class="bi bi-check-circle-fill text-coral me-2"></i> <b>Framework Front-End:</b> Bootstrap 5 (CSS/JS) untuk desain responsif.</li>
                        <li class="list-group-item px-0 fw-semibold"><i class="bi bi-check-circle-fill text-coral me-2"></i> <b>Geospasial:</b> Leaflet.js, Marker Cluster, Layer Control, Geocoding.</li>
                        <li class="list-group-item px-0 fw-semibold"><i class="bi bi-check-circle-fill text-coral me-2"></i> <b>Data:</b> GeoJSON statis sebagai representasi data spasial.</li>
                    </ul>
                </div>
                <div class="col-lg-6 text-center">
                    <div class="p-5 border border-teal rounded-3 shadow-lg bg-light-soft">
                        <i class="bi bi-file-earmark-code display-1 text-teal"></i>
                        <p class="lead mt-3 text-muted">Studi Kasus: Penerapan SIG Akademik.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="contact" class="py-5 bg-teal-dark text-white">
        <div class="container text-center">
            <h3 class="fw-bolder"><i class="bi bi-person-circle me-2 text-coral"></i> Kontak Pengembang Proyek</h3>
            <p class="lead text-light">Untuk kebutuhan presentasi dan evaluasi akademik.</p>
            <div class="row justify-content-center mt-4">
                <div class="col-md-4">
                    <p class="mb-0 fw-semibold"><i class="bi bi-person me-2"></i> Nama Pengembang:</p>
                    <p class="h5">Aprido Ilham</p>
                </div>
                <div class="col-md-4">
                    <p class="mb-0 fw-semibold"><i class="bi bi-envelope me-2"></i> Email Akademik:</p>
                    <p class="h5"><a href="mailto:apridoilham@idomac.local" class="text-white text-decoration-none">apridoilham@idomac.local</a></p>
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-teal-darker text-white py-4 border-top border-coral border-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p class="small mb-1">SIG-HALAL SAWANGAN - Final Academic Project</p>
                    <p class="text-muted small mb-0">Developed by Aprido Ilham | Kampus X</p>
                </div>
                <div class="col-md-6 text-md-end mt-3 mt-md-0">
                    <p class="text-muted small mb-0"><a href="#project-info" class="text-decoration-none text-coral">Dokumentasi Proyek</a> | V 14.0</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>
    <script src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>
    <script>
        const BASE_URL = '<?= base_url() ?>';
    </script>
    <script src="<?= base_url('assets/js/main.js?v=14.0') ?>"></script>
</body>
</html>