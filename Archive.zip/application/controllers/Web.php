<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller {

    public function index()
    {
        // Judul disesuaikan untuk tugas kuliah dengan fokus SIG
        $data = array(
            'title' => 'Sistem Informasi Geospasial Halal (SIG-Halal) Sawangan' 
        );
        $this->load->view('web/home', $data);
    }
}