document.addEventListener("DOMContentLoaded", function () {
	// 1. INISIALISASI PETA
	const sawanganCenter = [-6.3811, 106.7725];
	const map = L.map("map").setView(sawanganCenter, 14);

	// Define Base Layers
	const osm = L.tileLayer(
		"https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
		{
			attribution:
				'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
		}
	);
	osm.addTo(map);

	const satellite = L.tileLayer(
		"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
		{
			attribution: "Tiles &copy; Esri &mdash; Source: Esri",
		}
	);

	const baseLayers = {
		"Peta Jalan (OSM)": osm,
		"Citra Satelit (Esri)": satellite,
	};

	L.control.layers(baseLayers).addTo(map); // Add Layer Control

	// Add Geocoder (Search Box)
	L.Control.geocoder({
		defaultMarkGeocode: false,
		placeholder: "Cari Lokasi atau Alamat...",
	}).addTo(map);

	const markers = L.markerClusterGroup({
		chunkedLoading: true,
		spiderfyOnMaxZoom: true,
	});

	// Custom Halal Icon (Teal with Coral accent)
	const halalIcon = L.divIcon({
		html: `<div style="background:#00BCD4;color:#FF5722;width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:bold;box-shadow: 0 2px 5px rgba(0,0,0,0.4); border: 2px solid #FF5722;"><i class="bi bi-pin-map-fill"></i></div>`,
		className: "",
		iconSize: [34, 34],
		iconAnchor: [17, 34],
		popupAnchor: [0, -34],
	});

	let geoJsonData = null;

	// 2. FUNGSI MUAT DAN RENDER DATA
	function renderMarkers(data) {
		markers.clearLayers();

		L.geoJson(data, {
			pointToLayer: (feature, latlng) => L.marker(latlng, { icon: halalIcon }),
			onEachFeature: (feature, layer) => {
				const props = feature.properties;

				// Tentukan warna badge berdasarkan lembaga (dapatkan warna dari Bootstrap/Custom)
				let badgeClass = "bg-secondary";
				if (props.sertifikat.includes("BPJPH")) {
					badgeClass = "bg-primary";
				} else if (props.sertifikat.includes("MUI")) {
					badgeClass = "bg-success";
				} else if (props.sertifikat.includes("BPOM")) {
					badgeClass = "bg-info";
				}

				const is_open =
					props.jam_operasional && props.jam_operasional.includes("24 Jam");
				const statusHtml = is_open
					? `<span class="badge bg-success fw-bold text-white"><i class="bi bi-clock me-1"></i> BUKA (24 Jam)</span>`
					: `<span class="badge bg-warning fw-bold text-dark"><i class="bi bi-clock me-1"></i> Jam ${props.jam_operasional}</span>`;

				let popupContent = `
                    <div class="popup-custom" style="width: 250px;">
                        ${
													props.gambar
														? `<img src="${props.gambar}" class="img-fluid mb-2 rounded" alt="Foto Tempat Makan" style="width: 100%; height: 120px; object-fit: cover;">`
														: ""
												}
                        <h6 class="fw-bold text-dark mb-1">${
													props.nama || "Tempat Makan Halal"
												}</h6>
                        <p class="small mb-1 text-muted"><i class="bi bi-shop me-1"></i> **Jenis:** ${
													props.jenis_usaha || "-"
												}</p>
                        <p class="small mb-1 text-muted">${statusHtml}</p>
                        <p class="small mb-2 text-muted"><i class="bi bi-geo-alt me-1"></i> ${
													props.alamat || "Alamat tidak tersedia"
												}</p>
                        <hr class="my-1">
                        <span class="badge ${badgeClass} text-white"><i class="bi bi-patch-check-fill me-1"></i> Sertifikat ${
					props.sertifikat
				}</span>
                    </div>
                `;
				layer.bindPopup(popupContent, { minWidth: 250, maxWidth: 300 });
			},
		}).addTo(markers);

		map.addLayer(markers);

		// Fit bounds hanya jika ada marker
		if (markers.getLayers().length > 0) {
			map.fitBounds(markers.getBounds());
		} else {
			map.setView(sawanganCenter, 14);
		}
	}

	// 3. FUNGSI FILTER DATA
	function applyFilter() {
		if (!geoJsonData) return;

		const jenis = document.getElementById("filterJenis").value;
		const sertifikat = document.getElementById("filterSertifikat").value;

		const filteredFeatures = geoJsonData.features.filter((feature) => {
			const props = feature.properties;
			const jenisMatch = jenis === "all" || props.jenis_usaha === jenis;
			const sertifikatMatch =
				sertifikat === "all" ||
				props.sertifikat.includes(
					sertifikat
						.replace(" (Lembaga A)", "")
						.replace(" (Lembaga B)", "")
						.replace(" (Lembaga C)", "")
				);
			return jenisMatch && sertifikatMatch;
		});

		const filteredGeoJSON = {
			type: "FeatureCollection",
			features: filteredFeatures,
		};

		renderMarkers(filteredGeoJSON);
	}

	// 4. LOAD DATA & EVENT LISTENERS
	fetch(BASE_URL + "assets/sawangan_halal.geojson")
		.then((response) => response.json())
		.then((data) => {
			geoJsonData = data;
			renderMarkers(geoJsonData);
		});

	document
		.getElementById("filterJenis")
		.addEventListener("change", applyFilter);
	document
		.getElementById("filterSertifikat")
		.addEventListener("change", applyFilter);
	document.getElementById("resetFilter").addEventListener("click", function () {
		document.getElementById("filterJenis").value = "all";
		document.getElementById("filterSertifikat").value = "all";
		applyFilter();
	});
});
